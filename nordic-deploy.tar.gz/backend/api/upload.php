<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../utils/response.php';

class ImageUploadController {
    private $uploadDir;
    private $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
    private $maxFileSize = 5242880; // 5MB

    public function __construct() {
        // Set upload directory
        $this->uploadDir = __DIR__ . '/../uploads/rooms/';
        
        // Create directory if it doesn't exist
        if (!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0777, true);
        }
    }

    public function handleUpload() {
        try {
            // Check if file was uploaded
            if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
                $errorMsg = isset($_FILES['image']) ? $this->getUploadErrorMessage($_FILES['image']['error']) : 'No file uploaded';
                Response::error($errorMsg, 400);
                return;
            }

            $file = $_FILES['image'];

            // Validate file type
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mimeType = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);

            if (!in_array($mimeType, $this->allowedTypes)) {
                Response::error('Invalid file type. Only JPEG, PNG, and WebP images are allowed.', 400);
                return;
            }

            // Validate file size
            if ($file['size'] > $this->maxFileSize) {
                Response::error('File size exceeds 5MB limit.', 400);
                return;
            }

            // Generate unique filename
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'room_' . uniqid() . '_' . time() . '.' . strtolower($extension);
            $filepath = $this->uploadDir . $filename;

            // Move uploaded file
            if (!move_uploaded_file($file['tmp_name'], $filepath)) {
                Response::error('Failed to save uploaded file.', 500);
                return;
            }

            // Set proper permissions
            chmod($filepath, 0644);

            // Return success with file URL
            $fileUrl = '/backend/uploads/rooms/' . $filename;
            Response::success([
                'filename' => $filename,
                'url' => $fileUrl,
                'size' => $file['size']
            ]);

        } catch (Exception $e) {
            Response::error('Upload failed: ' . $e->getMessage(), 500);
        }
    }

    private function getUploadErrorMessage($errorCode) {
        $errors = [
            UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize directive',
            UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE directive',
            UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
            UPLOAD_ERR_NO_FILE => 'No file was uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION => 'Upload stopped by extension'
        ];
        return $errors[$errorCode] ?? 'Unknown upload error';
    }

    public function deleteImage() {
        try {
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($data['filename'])) {
                Response::error('Filename is required', 400);
                return;
            }

            $filepath = $this->uploadDir . basename($data['filename']);
            
            if (!file_exists($filepath)) {
                Response::error('File not found', 404);
                return;
            }

            if (unlink($filepath)) {
                Response::success(['message' => 'Image deleted successfully']);
            } else {
                Response::error('Failed to delete image', 500);
            }

        } catch (Exception $e) {
            Response::error('Delete failed: ' . $e->getMessage(), 500);
        }
    }
}

// Handle the request
$controller = new ImageUploadController();

$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'POST') {
    $controller->handleUpload();
} elseif ($method === 'DELETE') {
    $controller->deleteImage();
} else {
    Response::error('Method not allowed', 405);
}
