<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../utils/response.php';

class SuiteController {
    private $db;
    private $conn;

    public function __construct() {
        try {
            $this->db = Database::getInstance();
            $this->conn = $this->db->getConnection();
        } catch (Exception $e) {
            $this->conn = null;
        }
    }

    public function handleRequest() {
        try {
            $demo = isset($_GET['demo']) && $_GET['demo'] === 'true';

            if ($demo || !$this->conn) {
                $this->getDemoSuites();
                return;
            }

            $this->getAllSuites();
        } catch (Exception $e) {
            Response::error($e->getMessage(), 500);
        }
    }

    private function getDemoSuites() {
        $suites = [
            [
                'id' => 1,
                'name' => 'Ocean View Suite',
                'description' => 'Spacious suite with panoramic ocean views',
                'price_per_night' => 15000,
                'max_guests' => 4,
                'status' => 'available',
                'amenities' => 'King Bed, Ocean View, Balcony, WiFi, Minibar',
                'image_url' => 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800'
            ],
            [
                'id' => 2,
                'name' => 'Executive Suite',
                'description' => 'Luxurious suite perfect for business travelers',
                'price_per_night' => 18000,
                'max_guests' => 3,
                'status' => 'available',
                'amenities' => 'King Bed, Work Desk, WiFi, Coffee Machine',
                'image_url' => 'https://images.unsplash.com/photo-1591088398332-8a7791972843?w=800'
            ],
            [
                'id' => 3,
                'name' => 'Deluxe Room',
                'description' => 'Comfortable and elegant deluxe accommodation',
                'price_per_night' => 12000,
                'max_guests' => 2,
                'status' => 'available',
                'amenities' => 'Queen Bed, WiFi, Smart TV, Minibar',
                'image_url' => 'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800'
            ],
            [
                'id' => 4,
                'name' => 'Family Suite',
                'description' => 'Perfect for families with connecting rooms',
                'price_per_night' => 22000,
                'max_guests' => 6,
                'status' => 'occupied',
                'amenities' => 'Multiple Beds, Connecting Rooms, WiFi, Kitchenette',
                'image_url' => 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800'
            ],
            [
                'id' => 5,
                'name' => 'Penthouse Suite',
                'description' => 'Ultimate luxury with private terrace',
                'price_per_night' => 35000,
                'max_guests' => 4,
                'status' => 'available',
                'amenities' => 'King Bed, Private Terrace, Jacuzzi, Butler Service',
                'image_url' => 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=800'
            ]
        ];

        Response::success($suites);
    }

    private function getAllSuites() {
        try {
            $query = "SELECT * FROM rooms ORDER BY created_at DESC";
            $stmt = $this->conn->query($query);
            $suites = $stmt->fetchAll(PDO::FETCH_ASSOC);
            Response::success($suites);
        } catch (Exception $e) {
            // Fallback to demo if DB fails
            $this->getDemoSuites();
        }
    }
}

// Handle the request
$controller = new SuiteController();
$controller->handleRequest();
